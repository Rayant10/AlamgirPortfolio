
<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: ../login.php');
  }
?>
<?php
require('config.php');
 
   $product_name = $_POST['product_name'];
   $product_img = $_POST['product_img'];
   $product_price = $_POST['product_price'];
   $product_desc = $_POST['product_desc'];
 
   $sql_q = "INSERT INTO tbl_product (product_name, product_img, product_price, product_desc)
          VALUES ('$product_name,$product_img', '$product_price', '$product_desc')";
   
   $result = mysqli_query($con, $sql_q) or die(mysqli_error($con));
   
    if(mysqli_query($con, $result)){
		header("location: manage_product.php");
	} 
	else{
		echo "No INSERT";
	}






?>