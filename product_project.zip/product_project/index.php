<?php 
  ob_start();
  session_start();
  if($_SESSION['name']!='computer'){
    header('location: login.php');
  }
?>